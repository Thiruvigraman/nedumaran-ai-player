package com.rypera.nedumaranbridge;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

final class InventorySnapshot {
    private InventorySnapshot() {}

    static List<Map<String, Object>> capture(Player player) {
        List<Map<String, Object>> items = new ArrayList<>();
        ItemStack[] contents = player.getInventory().getStorageContents();
        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack item = contents[slot];
            if (item == null || item.getType().isAir()) continue;
            items.add(Map.of(
                    "slot", slot,
                    "material", item.getType().name(),
                    "amount", item.getAmount()
            ));
        }
        return items;
    }
}
