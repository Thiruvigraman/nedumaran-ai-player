package com.rypera.nedumaranbridge;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

public final class NedumaranBridge extends JavaPlugin {
    private Object fppApi;
    private HttpClient httpClient;
    private ExecutorService httpExecutor;
    private final AtomicBoolean requestInFlight = new AtomicBoolean(false);
    private String botName;
    private boolean renderEnabled;
    private String renderUrl;
    private String apiKey;
    private int requestTimeoutSeconds;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        botName = getConfig().getString("bot-name", "Nedumaran");
        renderEnabled = getConfig().getBoolean("render.enabled", false);
        renderUrl = getConfig().getString("render.url", "");
        apiKey = getConfig().getString("render.api-key", "");
        requestTimeoutSeconds = Math.max(2, getConfig().getInt("render.request-timeout-seconds", 8));

        try {
            var fpp = Bukkit.getPluginManager().getPlugin("FakePlayerPlugin");
            if (fpp == null || !fpp.isEnabled()) {
                throw new IllegalStateException("FakePlayerPlugin is not enabled");
            }
            Method getter = fpp.getClass().getMethod("getFppApi");
            fppApi = getter.invoke(fpp);
            if (fppApi == null) {
                throw new IllegalStateException("FPP returned a null API");
            }
        } catch (ReflectiveOperationException | RuntimeException ex) {
            getLogger().log(Level.SEVERE, "Could not connect to FPP API. Disabling bridge.", ex);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        int connectTimeout = Math.max(2, getConfig().getInt("render.connect-timeout-seconds", 5));
        httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(connectTimeout))
                .build();
        httpExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "NedumaranBridge-HTTP");
            thread.setDaemon(true);
            return thread;
        });

        long interval = Math.max(20L, getConfig().getLong("observation-interval-ticks", 100L));
        Bukkit.getScheduler().runTaskTimer(this, this::collectObservation, 40L, interval);
        getLogger().info("Connected to FPP API. Observation-only mode is active for bot '" + botName + "'.");
        getLogger().info("Render delivery is " + (renderEnabled ? "enabled" : "disabled") + ".");
    }

    private void collectObservation() {
        try {
            Method getBot = fppApi.getClass().getMethod("getBot", String.class);
            Object optional = getBot.invoke(fppApi, botName);
            Object bot = optional.getClass().getMethod("orElse", Object.class).invoke(optional, new Object[]{null});
            if (bot == null) {
                getLogger().fine("Bot '" + botName + "' is not currently registered with FPP.");
                return;
            }

            Object entity = call(bot, "getEntity");
            Map<String, Object> observation = new LinkedHashMap<>();
            observation.put("bot", botName);
            observation.put("uuid", String.valueOf(call(bot, "getUuid")));
            observation.put("fppVersion", String.valueOf(call(fppApi, "getVersion")));
            observation.put("alive", call(bot, "isAlive"));
            observation.put("respawning", call(bot, "isRespawning"));
            observation.put("deathCount", call(bot, "getDeathCount"));
            observation.put("world", call(bot, "getWorldName"));

            Object location = call(bot, "getLocation");
            Map<String, Object> position = new LinkedHashMap<>();
            position.put("x", call(location, "getX"));
            position.put("y", call(location, "getY"));
            position.put("z", call(location, "getZ"));
            observation.put("position", position);

            observation.put("health", call(bot, "getHealth"));
            observation.put("maxHealth", call(bot, "getMaxHealth"));
            observation.put("gameMode", String.valueOf(call(bot, "getGameMode")));
            observation.put("uptimeMillis", ((java.time.Duration) call(bot, "getUptime")).toMillis());

            if (entity instanceof org.bukkit.entity.Player player) {
                observation.put("foodLevel", player.getFoodLevel());
                observation.put("saturation", player.getSaturation());
                observation.put("level", player.getLevel());
                observation.put("experience", player.getExp());
                observation.put("onGround", player.isOnGround());
                observation.put("inWater", player.isInWater());
                observation.put("inLava", player.isInLava());
                observation.put("inventory", InventorySnapshot.capture(player));
            } else {
                observation.put("entityAvailable", false);
            }

            String json = Json.encode(observation);
            if (renderEnabled) {
                sendObservation(json);
            } else {
                getLogger().fine("Observation collected: " + json);
            }
        } catch (Exception ex) {
            getLogger().log(Level.WARNING, "Could not collect FPP observation: " + ex.getMessage(), ex);
        }
    }

    private void sendObservation(String json) {
        if (renderUrl == null || !renderUrl.startsWith("https://")) {
            getLogger().warning("Render URL must use HTTPS. Observation was not sent.");
            return;
        }
        if (apiKey == null || apiKey.isBlank()) {
            getLogger().warning("Render API key is empty. Observation was not sent.");
            return;
        }
        if (!requestInFlight.compareAndSet(false, true)) return;

        httpExecutor.submit(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(renderUrl))
                        .timeout(Duration.ofSeconds(requestTimeoutSeconds))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + apiKey)
                        .POST(HttpRequest.BodyPublishers.ofString(json))
                        .build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() < 200 || response.statusCode() >= 300) {
                    getLogger().warning("Render observation endpoint returned HTTP " + response.statusCode());
                } else {
                    getLogger().fine("Observation delivered to Render (HTTP " + response.statusCode() + ").");
                }
            } catch (Exception ex) {
                getLogger().warning("Render observation delivery failed: " + ex.getMessage());
            } finally {
                requestInFlight.set(false);
            }
        });
    }

    private static Object call(Object target, String methodName) throws ReflectiveOperationException {
        return target.getClass().getMethod(methodName).invoke(target);
    }

    @Override
    public void onDisable() {
        if (httpExecutor != null) httpExecutor.shutdownNow();
        getLogger().info("NedumaranBridge stopped.");
    }
}
