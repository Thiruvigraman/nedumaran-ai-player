# NedumaranBridge 0.1.0 — observation-only prototype

This is the first, read-only integration prototype for Mettioli SMP.

## Behavior
- Requires the FPP plugin to be enabled.
- Resolves FPP's public API through the plugin's verified `getFppApi()` accessor using reflection.
- Polls the configured bot every 100 ticks by default.
- Collects bot state and, when the Bukkit Player entity is available, food level and a compact storage-inventory snapshot.
- Does not issue movement, mining, combat, inventory mutation, respawn, or console commands.
- Render delivery is disabled by default.

## Compatibility target
- Paper 1.21.11
- Java 21
- FPP 2.1.8 API surface

The bridge uses reflection for FPP calls so it does not bundle or compile against FPP internals. The `depend: [FakePlayerPlugin]` declaration ensures FPP loads first.

## Build
Run `gradle build` with JDK 21. The output JAR is under `build/libs/`.

## Render delivery
The Render service must implement `POST /api/v1/bot/observe` and accept a Bearer token before enabling `render.enabled`. Configure the endpoint and API key in `plugins/NedumaranBridge/config.yml`. Never commit the API key.

The existing Render service does not yet implement this endpoint. Keep `render.enabled: false` until that service update is deployed.

## Deployment warning
This JAR has not been compiled or tested against the live Mettioli server. Do not install it on production until it is built and validated on a test server. PowerUpStack Workshop-only installation may prevent installing custom JARs; confirm a supported installation path first.
