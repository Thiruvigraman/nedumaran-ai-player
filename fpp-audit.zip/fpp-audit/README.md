# FPP 2.1.8 source audit package

This package contains selected files extracted from the user-provided
Fake-Player-plugin-2.0-master.zip archive for GitHub Copilot source review.

## Contents
- FPP public API interfaces
- FPP bot implementation
- FPP bot entity/death listener
- All FPP API event source files
- FPP configuration and plugin descriptor
- Gradle build and settings files

## Important
These are source excerpts for inspection, not a standalone build project.
Preserve the original FPP source and do not replace the installed FPP plugin.
Copilot should verify method signatures and lifecycle behavior from these files.
Do not assume files omitted from this audit package do not exist in the original project.
